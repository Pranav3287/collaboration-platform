package com.Test.collaboration_platform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CollaborationPlatformApplicationTests {

	@Test
	void contextLoads() {
	}

}
